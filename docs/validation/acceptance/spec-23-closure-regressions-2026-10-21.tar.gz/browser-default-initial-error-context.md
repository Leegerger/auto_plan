# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: plan-preview.spec.ts >> editor previews daily quantities and lossless hours with visible boundary issues
- Location: tests/plan-preview.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('容量与顺序通过', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('容量与顺序通过', { exact: true }) with timeout 5000ms
  - waiting for getByText('容量与顺序通过', { exact: true })

```

```yaml
- banner:
  - link "Bonding 生产排程":
    - /url: /planning/
  - navigation:
    - link "工作台":
      - /url: /planning/
    - link "输入资料":
      - /url: /planning/inputs
    - link "首次接入与需求":
      - /url: /planning/initialize
    - link "共享计划":
      - /url: /planning/plans/shared
    - link "日内详情":
      - /url: /planning/plans/preview
    - text: PREVIEW_EDITOR
    - button "退出登录"
- main:
  - heading "日内详情与工时预览" [level=1]
  - paragraph: 生产日从北京时间08:00起算。同日同线同 Recipe 汇总投入与工时，只向上取整一次。此处预览尚未保存。
  - text: 生产日期
  - textbox "详情生产日期": 2026-10-14
  - text: 线体
  - combobox "详情线体":
    - option "测试线 (UI_L)"
    - option "预览线体 (PREVIEW_L)" [selected]
  - text: 起始 Recipe
  - combobox "起始 Recipe":
    - option "未知，首次生产不扣切机" [selected]
    - option "测试工艺 (UI_R)"
    - option "预览工艺 (PREVIEW_R)"
  - button "重新读取资料"
  - text: 资料版本 4
  - heading "生产段顺序与精确工时" [level=2]
  - paragraph: 工时可填十进制或分数，如0.024001或1/3。按数量生成工时依据会重新分配全部段工时与切机；工时没有最小步长。
  - button "添加生产段"
  - table "生产段详情":
    - rowgroup:
      - row "生产日期 线体 顺序 机种 投入片数 精确工时 操作":
        - columnheader "生产日期"
        - columnheader "线体"
        - columnheader "顺序"
        - columnheader "机种"
        - columnheader "投入片数"
        - columnheader "精确工时"
        - columnheader "操作"
    - rowgroup:
      - row "2026-10-14 PREVIEW_L 0 预览机种 (PREVIEW_M) 2 0.024001 移除":
        - cell "2026-10-14":
          - textbox "生产日期 第1段": 2026-10-14
        - cell "PREVIEW_L":
          - combobox "线体 第1段":
            - option "UI_L"
            - option "PREVIEW_L" [selected]
        - cell "0":
          - textbox "顺序 第1段": "0"
        - cell "预览机种 (PREVIEW_M)":
          - combobox "机种 第1段":
            - option "预览机种 (PREVIEW_M)" [selected]
        - cell "2":
          - textbox "投入片数 第1段": "2"
        - cell "0.024001":
          - textbox "精确工时 第1段": "0.024001"
        - cell "移除":
          - button "移除"
  - heading "有向切机与跨日分配" [level=2]
  - paragraph: 跨日分配合计必须精确等于切机参数，整次只计一次。每日工时校验通过仍需现场落实连续切机。
  - button "添加切机"
  - heading "普通空闲预算" [level=2]
  - paragraph: 只有未分配给生产、Holiday、保养或实验的工时可抵扣。一天一份预算，同日不同切机共用。
  - button "添加普通空闲"
  - button "预览精确工时"
  - button "按数量生成工时依据"
  - region "工时预览结果":
    - heading "容量或顺序存在问题" [level=2]
    - paragraph: 切机次数 0。产出与确认按下方固定归属顺序核算。
    - table "预览问题":
      - rowgroup:
        - row "生产日期 线体 机种 需求周 相关批次 问题":
          - columnheader "生产日期"
          - columnheader "线体"
          - columnheader "机种"
          - columnheader "需求周"
          - columnheader "相关批次"
          - columnheader "问题"
      - rowgroup:
        - row "2026-10-14 PREVIEW_L 投入或空闲安排超出冻结的十五周排程窗口":
          - cell "2026-10-14"
          - cell "PREVIEW_L"
          - cell
          - cell
          - cell
          - cell "投入或空闲安排超出冻结的十五周排程窗口"
    - article:
      - heading "2026-10-14 · PREVIEW_L · 日可用 24 小时" [level=3]
      - paragraph:
        - text: 生产 0.0240 小时
        - group: 查看精确值 小时
      - paragraph:
        - text: 切机 0.0000 小时
        - group: 查看精确值 小时
      - paragraph:
        - text: 总占用 0.0240 小时
        - group: 查看精确值 小时
      - paragraph: 日末 Recipe PREVIEW_R
      - table "Recipe 容量依据":
        - rowgroup:
          - row "Recipe 汇总投入 生产分配工时 全日产能 投入上限 参数状态":
            - columnheader "Recipe"
            - columnheader "汇总投入"
            - columnheader "生产分配工时"
            - columnheader "全日产能"
            - columnheader "投入上限"
            - columnheader "参数状态"
        - rowgroup:
          - row "PREVIEW_R 2 0.0240 小时 1000 2 已知":
            - cell "PREVIEW_R"
            - cell "2"
            - cell "0.0240 小时":
              - text: 0.0240 小时
              - group: 查看精确值 小时
            - cell "1000"
            - cell "2"
            - cell "已知"
    - region "产出需求与确认核算":
      - heading "产出、需求归属与确认" [level=2]
      - paragraph: 存在硬冲突、必要未确认或未完成计算，须处理后再采用。
      - paragraph: 预计产出 0 片；窗口外 0 片；未分配 0 片。总体按时率 不适用。
      - paragraph: 缺口按需求减去有效按时与迟交覆盖计算。待确认是缺口中已归属、尚未有效的部分，不与缺口重复相加。迟交补足不改写按时率。
      - table "周需求覆盖":
        - rowgroup:
          - row "机种 需求周周一 需求 有效按时 按时率 有效迟交 未补足缺口 待物料 待出货":
            - columnheader "机种"
            - columnheader "需求周周一"
            - columnheader "需求"
            - columnheader "有效按时"
            - columnheader "按时率"
            - columnheader "有效迟交"
            - columnheader "未补足缺口"
            - columnheader "待物料"
            - columnheader "待出货"
        - rowgroup
      - heading "产出来源与逐笔取整" [level=3]
      - heading "来源、需求与投入归属" [level=3]
      - paragraph: 同来源同需求周的归属投入是整组值，各产出分笔重复展示该组依据，不能将其逐行相加。比例分母不含未分配产出。
      - table "产出归属确认明细":
        - rowgroup:
          - row "来源 需求周 产出日 归属产出 该周来源产出/比例分母 归属投入/未取整份额 已确认投入/缺确认投入 物料已满足产出 待物料/待出货产出 有效按时/迟交 批次使用":
            - columnheader "来源"
            - columnheader "需求周"
            - columnheader "产出日"
            - columnheader "归属产出"
            - columnheader "该周来源产出/比例分母"
            - columnheader "归属投入/未取整份额"
            - columnheader "已确认投入/缺确认投入"
            - columnheader "物料已满足产出"
            - columnheader "待物料/待出货产出"
            - columnheader "有效按时/迟交"
            - columnheader "批次使用"
        - rowgroup
      - heading "确认批次额度" [level=3]
      - table "确认批次使用":
        - rowgroup:
          - row "机种/需求周 类型/批次 状态 日期边界 原额度 使用量 余量":
            - columnheader "机种/需求周"
            - columnheader "类型/批次"
            - columnheader "状态"
            - columnheader "日期边界"
            - columnheader "原额度"
            - columnheader "使用量"
            - columnheader "余量"
        - rowgroup
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('editor previews daily quantities and lossless hours with visible boundary issues', async ({ page }) => {
  4  |   await page.goto('/planning/login')
  5  |   await page.getByRole('textbox', { name: '公司账号' }).fill('admin')
  6  |   await page.getByLabel('公司密码', { exact: true }).fill('company-secret')
  7  |   await page.getByRole('button', { name: '登录', exact: true }).click()
  8  |   await page.getByRole('link', { name: '账号授权', exact: true }).click()
  9  |   await page.getByRole('textbox', { name: '授权账号' }).fill('PREVIEW_EDITOR')
  10 |   await page.getByRole('group', { name: '角色' }).getByText('业务编辑者', { exact: true }).click()
  11 |   await page.getByRole('button', { name: '保存授权' }).click()
  12 |   await expect(page.getByText('已保存 PREVIEW_EDITOR 的授权', { exact: true })).toBeVisible()
  13 |   await page.getByRole('button', { name: '退出登录' }).click()
  14 |   await page.getByRole('textbox', { name: '公司账号' }).fill('preview_editor')
  15 |   await page.getByLabel('公司密码', { exact: true }).fill('company-secret')
  16 |   await page.getByRole('button', { name: '登录', exact: true }).click()
  17 |   await expect(page.getByRole('link', { name: '输入资料', exact: true })).toBeVisible()
  18 |   const current = await (await page.request.get('/planning/api/inputs')).json()
  19 |   const changes = {
  20 |     recipes: [{ code: 'PREVIEW_R', name: '预览工艺', active: true }],
  21 |     lines: [{ code: 'PREVIEW_L', name: '预览线体', active: true }],
  22 |     models: [{ code: 'PREVIEW_M', name: '预览机种', active: true, recipe_code: 'PREVIEW_R' }],
  23 |     capacities: [{ month: '2026-10', recipe_code: 'PREVIEW_R', line_code: 'PREVIEW_L', pieces: 1000 }],
  24 |     line_yields: [{ month: '2026-10', percent: '100' }],
  25 |     model_yields: [{ month: '2026-10', model_code: 'PREVIEW_M', percent: '100' }],
  26 |     cycle_times: [{ model_code: 'PREVIEW_M', days: '0' }],
  27 |   }
  28 |   const applied = await page.request.post('/planning/api/inputs/apply', {
  29 |     headers: { Origin: 'https://localhost:8774', 'X-Auto-Plan-Request': '1' },
  30 |     data: { base_version: current.input_version, changes },
  31 |   })
  32 |   expect(applied.ok()).toBeTruthy()
  33 |   await page.getByRole('link', { name: '日内详情', exact: true }).click()
  34 |   await expect(page.getByRole('heading', { name: '日内详情与工时预览' })).toBeVisible()
  35 |   await page.getByLabel('详情生产日期', { exact: true }).fill('2026-10-14')
  36 |   await page.getByLabel('详情线体', { exact: true }).selectOption('PREVIEW_L')
  37 |   await page.getByRole('button', { name: '添加生产段', exact: true }).click()
  38 |   await page.getByLabel('机种 第1段', { exact: true }).selectOption('PREVIEW_M')
  39 |   await page.getByLabel('投入片数 第1段', { exact: true }).fill('2')
  40 |   await page.getByLabel('精确工时 第1段', { exact: true }).fill('0.024')
  41 |   await page.getByRole('button', { name: '预览精确工时', exact: true }).click()
  42 |   await expect(page.getByRole('table', { name: '预览问题' })).toContainText('超过精确工时上限1')
  43 |   await page.getByLabel('精确工时 第1段', { exact: true }).fill('0.024001')
  44 |   await page.getByRole('button', { name: '预览精确工时', exact: true }).click()
> 45 |   await expect(page.getByText('容量与顺序通过', { exact: true })).toBeVisible()
     |                                                            ^ Error: expect(locator).toBeVisible() failed
  46 |   await expect(page.getByRole('table', { name: 'Recipe 容量依据' })).toContainText('0.0240')
  47 |   await page.getByRole('table', { name: 'Recipe 容量依据' }).getByText('查看精确值', { exact: true }).click()
  48 |   await expect(page.getByRole('table', { name: 'Recipe 容量依据' })).toContainText('24001/1000000')
  49 |   await page.getByLabel('投入片数 第1段', { exact: true }).fill('1')
  50 |   await page.getByLabel('精确工时 第1段', { exact: true }).fill('1/1000000')
  51 |   await page.getByRole('button', { name: '预览精确工时', exact: true }).click()
  52 |   await expect(page.getByRole('table', { name: 'Recipe 容量依据' })).toContainText('<0.0001')
  53 |   await page.getByRole('button', { name: '按数量生成工时依据', exact: true }).click()
  54 |   await expect(page.getByText('已生成精确工时依据，尚未保存', { exact: true })).toBeVisible()
  55 |   await page.screenshot({ path: '/tmp/auto-plan-spec-23/plan-preview-ui.png', fullPage: true })
  56 | })
  57 | 
```