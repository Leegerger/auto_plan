import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/root/codes/vibe_coding/auto_plan_2')
output = Path('/tmp/spec-23-close')
environment = {key: value for key, value in os.environ.items() if not key.startswith('AUTO_PLAN_')}
environment.update(AUTO_PLAN_TEST_ORACLE='0', PYTHONPATH='src:.', PLAYWRIGHT_BROWSERS_PATH='/tmp/auto-plan-playwright')
checks = [
    ('python', [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', 'tests', 'scripts/acceptance', '--junitxml=' + str(output / 'python.xml')], root, {}, 900),
    ('frontend-build', ['npm', 'run', 'build'], root / 'frontend', {}, 180),
    ('node-contracts', ['node', '--test', *[str(path.relative_to(root)) for path in sorted((root / 'frontend/tests/acceptance').glob('*.test.mjs'))]], root, {}, 300),
    ('browser-default', ['npm', 'run', 'test:e2e', '--', '--reporter=line'], root / 'frontend', {'AUTO_PLAN_ACCEPTANCE_PYTHON': str(root / '.venv/bin/python')}, 300),
    ('browser-shared', ['npm', 'run', 'test:e2e', '--', 'shared-plans.spec.ts', 'manual-editing.spec.ts', 'quantity-change.spec.ts', 'stability.spec.ts', 'history.spec.ts', 'local-recovery.spec.ts', 'jobs.spec.ts', 'jobs-live.spec.ts', 'acceptance/navigation.spec.ts', '--reporter=line'], root / 'frontend', {'AUTO_PLAN_BROWSER_TRANSACTIONS_FIXTURE': '1'}, 600),
    ('browser-initialization', ['npm', 'run', 'test:e2e', '--', 'initialization.spec.ts', '--reporter=line'], root / 'frontend', {'AUTO_PLAN_BROWSER_INITIALIZATION_FIXTURE': '1'}, 180),
    ('browser-output', ['npm', 'run', 'test:e2e', '--', 'output.spec.ts', '--reporter=line'], root / 'frontend', {'AUTO_PLAN_BROWSER_OUTPUT_FIXTURE': '1'}, 180),
    ('browser-reset', ['npm', 'run', 'test:e2e', '--', 'execution-reset.spec.ts', '--reporter=line'], root / 'frontend', {'AUTO_PLAN_BROWSER_RESET_FIXTURE': '1'}, 180),
]
results = []
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
if '--resume-after-python' in sys.argv:
    import xml.etree.ElementTree as ET
    report = ET.parse(output / 'python.xml').getroot()[0]
    assert report.attrib['tests'] == '535'
    assert report.attrib['failures'] == report.attrib['errors'] == '0'
    results = json.loads((output / 'regression-results.json').read_text())[:1]
    results[0]['assertion_result'] = dict(report.attrib)
    results[0]['runner_note'] = 'All 535 test results were written before the outer 900-second process guard expired; preserve exit 124 separately from assertion results.'
    checks = [
        ('business-regressions', [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', 'tests', '--junitxml=' + str(output / 'business-regressions.xml')], root, {}, 900),
        ('adapter-pin-regressions', [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', 'scripts/acceptance/test_adapter_read_pin.py', '--junitxml=' + str(output / 'adapter-pin-regressions.xml')], root, {}, 120),
        *checks[1:],
    ]
if '--resume-after-business' in sys.argv:
    import xml.etree.ElementTree as ET
    report = ET.parse(output / 'business-regressions.xml').getroot()[0]
    failures = [case for case in report.findall('testcase') if case.find('failure') is not None]
    assert report.attrib['tests'] == '442'
    assert report.attrib['failures'] == '1' and report.attrib['errors'] == '0'
    assert len(failures) == 1
    assert failures[0].attrib['name'] == 'test_fresh_compute_commits_complete_candidate_and_reference_application_preserves_independent_edit'
    results = json.loads((output / 'regression-results.json').read_text())[:2]
    results[1]['assertion_result'] = dict(report.attrib)
    results[1]['runner_note'] = 'Preserved original functional-fixture timeout failure; job-functional-regressions reruns the changed module after the explicit functional budget correction.'
    checks = [
        ('job-functional-regressions', [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', 'tests/test_jobs.py', 'tests/test_browser_job_freeze.py', '--junitxml=' + str(output / 'job-functional-regressions.xml')], root, {}, 240),
        ('adapter-pin-regressions', [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', 'scripts/acceptance/test_adapter_read_pin.py', '--junitxml=' + str(output / 'adapter-pin-regressions.xml')], root, {}, 120),
        *checks[1:],
    ]
if '--resume-browser' in sys.argv:
    results = json.loads((output / 'regression-results.json').read_text())
    checks = checks[3:]
if '--resume-shared' in sys.argv:
    results = json.loads((output / 'regression-results.json').read_text())
    checks = [('browser-shared', [str(root / '.venv/bin/python'), str(output / 'run-shared-browser-files.py')], root, {'AUTO_PLAN_BROWSER_TRANSACTIONS_FIXTURE': '1'}, 600), *checks[5:]]
if '--resume-default' in sys.argv:
    results = json.loads((output / 'regression-results.json').read_text())
    checks = [checks[3]]
if '--resume-final-browsers' in sys.argv:
    results = json.loads((output / 'regression-results.json').read_text())
    checks = [checks[3], ('browser-shared', [str(root / '.venv/bin/python'), str(output / 'run-shared-browser-files.py')], root, {'AUTO_PLAN_BROWSER_TRANSACTIONS_FIXTURE': '1'}, 600), *checks[5:]]
if '--resume-node' in sys.argv:
    results = json.loads((output / 'regression-results.json').read_text())
    name, command, cwd, extra, timeout = checks[2]
    checks = [(name, command, cwd, extra | {'AUTO_PLAN_ACCEPTANCE_PYTHON': str(root / '.venv/bin/python')}, timeout)]
for name, command, cwd, extra, timeout in checks:
    print('Starting ' + name, flush=True)
    started = time.monotonic()
    log_path = output / (name + '.log')
    with log_path.open('w') as log:
        try:
            result = subprocess.run(command, cwd=cwd, env=environment | extra, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    row = {'name': name, 'command': command, 'cwd': str(cwd), 'environment_overrides': extra | {'AUTO_PLAN_TEST_ORACLE': '0'}, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started, 'log': str(log_path), 'source_commit': source_commit}
    results.append(row)
    (output / 'regression-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code:
        print(log_path.read_text()[-16000:], flush=True)
        raise SystemExit(code)
