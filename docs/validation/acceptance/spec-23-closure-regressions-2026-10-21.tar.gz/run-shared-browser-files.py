import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/root/codes/vibe_coding/auto_plan_2')
output = Path('/tmp/spec-23-close/shared-browser-files')
output.mkdir(exist_ok=True)
files = ['shared-plans.spec.ts', 'manual-editing.spec.ts', 'quantity-change.spec.ts', 'stability.spec.ts', 'history.spec.ts', 'local-recovery.spec.ts', 'jobs.spec.ts', 'jobs-live.spec.ts', 'acceptance/navigation.spec.ts']
results = []
for filename in files:
    name = filename.replace('/', '-').removesuffix('.spec.ts')
    command = ['npm', 'run', 'test:e2e', '--', filename, '--reporter=line,json']
    environment = os.environ | {'PLAYWRIGHT_JSON_OUTPUT_NAME': str(output / (name + '.json'))}
    started = time.monotonic()
    print('Fresh fixture: ' + filename, flush=True)
    with (output / (name + '.log')).open('w') as log:
        try:
            result = subprocess.run(command, cwd=root / 'frontend', env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=180)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    row = {'file': filename, 'command': command, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started, 'log': name + '.log', 'json_report': name + '.json'}
    results.append(row)
    (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    print((output / (name + '.log')).read_text()[-5000:], flush=True)
    if code:
        raise SystemExit(code)
