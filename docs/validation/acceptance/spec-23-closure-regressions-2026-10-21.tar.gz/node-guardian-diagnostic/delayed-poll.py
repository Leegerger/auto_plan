"""Pause only this test's owned guardian until its real worker settles."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root=Path('/tmp/spec-23-node-functional-timing')
label=sys.argv[1]
out=Path('/tmp/spec-23-node-guardian-diagnostic')
known=set(Path('/tmp').glob('auto-plan-functional-poll-*'))
process=subprocess.Popen(['node','--test','--test-name-pattern=late guardian polling uses actual owned readiness time',
    'frontend/tests/acceptance/functional-worker.test.mjs'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
guardian=None
resumed=False
record={}
try:
    end=time.monotonic()+8
    while time.monotonic()<end:
        fresh=set(Path('/tmp').glob('auto-plan-functional-poll-*'))-known
        if fresh:
            directory=next(iter(fresh))
            phase_file=directory/'functional-phase.json'
            if phase_file.exists():
                phase=json.loads(phase_file.read_text())
                if phase.get('sequence')==1:
                    worker=phase['pid']
                    guardian=int(Path(f'/proc/{worker}/stat').read_text().rsplit(')',1)[1].split()[1])
                    owner=guardian
                    while owner!=process.pid and owner>1:
                        owner=int(Path(f'/proc/{owner}/stat').read_text().rsplit(')',1)[1].split()[1])
                    assert owner==process.pid,'Refuse to pause a process outside this test.'
                    # Let the first 800ms poll observe readiness; delay only
                    # the following action-deadline poll until settlement.
                    time.sleep(0 if label=='green-first-poll' else .9)
                    os.kill(guardian,signal.SIGSTOP)
                    record={'output':str(directory),'guardian_pid':guardian,'ready':phase,'stopped_epoch_ms':time.time()*1000}
                    break
        time.sleep(.02)
    assert guardian,'Owned ready phase was not observed.'
    while time.monotonic()<end:
        phase=json.loads(phase_file.read_text())
        if phase.get('sequence')==2:
            record['settled']=phase
            break
        time.sleep(.02)
    assert record.get('settled'),'Real worker did not settle while its guardian was delayed.'
finally:
    if guardian:
        os.kill(guardian,signal.SIGCONT)
        resumed=True
        record['resumed_epoch_ms']=time.time()*1000
text,_=process.communicate(timeout=12)
(out/f'{label}.log').write_text(text)
record['exit_code']=process.returncode
record['cleanup']=json.loads((directory/'controller-cleanup.json').read_text())
record['interruption']=json.loads((directory/'controller-interruption.json').read_text())
(out/f'{label}.json').write_text(json.dumps(record,indent=2)+'\n')
print(text)
print(json.dumps(record,indent=2))
raise SystemExit(process.returncode)
