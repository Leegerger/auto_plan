# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: local-recovery.spec.ts >> unsent new segments recover by choice with original tokens and whole unchecked actions
- Location: tests/local-recovery.spec.ts:24:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/已共享保存修订/)
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/已共享保存修订/) with timeout 5000ms
  - waiting for getByText(/已共享保存修订/)

```

```yaml
- banner:
  - link "Bonding 生产排程":
    - /url: /planning/
  - navigation:
    - link "工作台":
      - /url: /planning/
    - link "输入资料":
      - /url: /planning/inputs
    - link "首次接入与需求":
      - /url: /planning/initialize
    - link "共享计划":
      - /url: /planning/plans/shared
    - link "日内详情":
      - /url: /planning/plans/preview
    - text: SHARED_EDITOR
    - button "退出登录"
- main:
  - heading "共享计划" [level=1]
  - paragraph: 待处理共享草稿 · 共享修订 4 · 输入版本 1 · 最近采用版 0
  - alert: 请明确保存为待处理草稿
  - status: 预览完成，尚未共享
  - region "本机临时稿恢复":
    - heading "本机临时稿" [level=2]
    - paragraph: 本机编号 main。记录按当前路径、账号及草稿号隔离，一般保留 30 天，待核实操作号会保留到核实。只保存操作与原始版本。换电脑前请共享保存 Oracle。
    - status: 已暂存本机，尚未共享
    - button "丢弃本机临时稿"
    - paragraph: 原共享修订 3 / 当前 4
    - paragraph: 原输入版本 1 / 当前 1
    - paragraph: 原最近采用版 0 / 当前 0
    - table "本机恢复期间的共享变更":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 变更事项 原共享值 最新共享值":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "变更事项"
            - columnheader "原共享值"
            - columnheader "最新共享值"
      - table:
        - rowgroup:
          - row "2026-10-17 L N 生产段 无 id independent-recovery-row；date 2026-10-17；line_code L；order 0；model_code N；quantity 3；hours 1":
            - cell "2026-10-17"
            - cell "L"
            - cell "N"
            - cell "生产段"
            - cell "无"
            - cell "id independent-recovery-row；date 2026-10-17；line_code L；order 0；model_code N；quantity 3；hours 1"
    - paragraph: 恢复后尚未共享。预览使用原版本，遇到关联变更会保留动作并列出差异；按最新资料重新预览须由你明确选择。
    - button "重试本机暂存"
    - button "新建本机临时稿"
    - text: 切换本机草稿
    - combobox "本机草稿编号":
      - option "main" [selected]
    - list:
      - listitem:
        - text: main 本机记录
        - button "导出本机稿 main JSON": 导出 JSON
    - paragraph: 未暂存表示仅保留在当前页面；已暂存本机尚未写入 Oracle；共享保存与正式采用分别由服务器确认。断网与保存结果未知时停止编辑。
  - region "计算任务":
    - heading "计算任务" [level=2]
    - paragraph: 计算使用已保存的共享草稿和完整输入。离开页面或退出登录后，任务继续执行。
    - paragraph: 最多等待 20 个任务，同时计算 1 个任务；每两秒更新任务状态。状态更新不延长候选内容保留期。
    - status: 本机仍有未共享动作，请先共享保存或处理本机动作后再提交计算。
    - button "重新读取计算来源" [disabled]
    - group "提交已保存的共享计划":
      - text: 提交已保存的共享计划 计算模式
      - combobox "计算模式" [disabled]:
        - option "局部调整" [disabled] [selected]
        - option "新周排程" [disabled]
        - option "全部重排" [disabled]
      - text: 计算范围起日
      - textbox "计算范围起日" [disabled]: 2026-10-12
      - text: 计算范围终日
      - textbox "计算范围终日" [disabled]: 2026-10-18
      - text: 计算线体
      - listbox "计算线体" [disabled]:
        - option "L 一线" [disabled] [selected]
      - text: 计算机种，不选表示全部
      - listbox "计算机种" [disabled]:
        - option "M 机种一" [disabled]
        - option "N 机种二" [disabled]
        - option "P 机种三" [disabled]
      - text: 求解策略
      - combobox "求解策略" [disabled]:
        - option "混合策略" [disabled] [selected]
        - option "CP-SAT" [disabled]
        - option "HiGHS" [disabled]
      - text: 计算时限，秒
      - spinbutton "计算时限" [disabled]: "20"
      - text: 候选数量
      - spinbutton "候选数量" [disabled]: "1"
      - paragraph: 每个任务使用单线程求解。
    - button "提交计算任务" [disabled]
    - list "持久计算任务":
      - listitem:
        - paragraph: aeae3e9d-5903-4333-8b66-23f1c679ab8d · 执行状态 已完成 · 提交人 SHARED_EDITOR · 原共享修订 3 · 输入版本 1 · 最近采用版 0
        - paragraph: order_after_recipe_blocks 固定数量的 Recipe 状态路径；容量及边界仍需完整精确工时检查
        - paragraph: 计算结果 输入不完整 · 用时 0.029794178903102875 秒 · 未证明全局最优
        - group: 计算阶段与界限
        - paragraph: 2027-01-18 L M Recipe 汇总投入100超过精确工时上限0
        - paragraph: 2027-01-18 L M 缺少全日产能，按零计算，待补充
        - paragraph: 2027-01-18 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成
        - paragraph: 2027-01-18 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成
        - paragraph: 2027-01-24 L M Recipe 汇总投入101超过精确工时上限0
        - paragraph: 2027-01-24 L M 缺少全日产能，按零计算，待补充
        - paragraph: 2027-01-24 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成
        - paragraph: 2027-01-24 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成
        - paragraph: 2027-01-18 L M 投入来源缺少关键良率或 Cycle Time
        - paragraph: 2027-01-18 L M 投入来源缺少关键良率或 Cycle Time
        - paragraph: 2027-01-24 L M 投入来源缺少关键良率或 Cycle Time
        - paragraph: 2027-01-24 L M 投入来源缺少关键良率或 Cycle Time
        - button "按原输入重新计算"
        - paragraph: 重新计算沿用该任务冻结的原始计划、输入和调整范围。
  - region "历史版本":
    - heading "历史版本" [level=2]
    - paragraph: 历史按当时需求、参数、确认和指标快照展示。共享草稿可在保存后30天内恢复，采用版长期保留。恢复先加入本机动作，按当前资料、事实和锁定检查，再由你共享保存及明确采用。
    - text: 选择历史版本
    - combobox "选择历史版本":
      - option "共享草稿 · 修订 4 · SHARED_EDITOR · 2026-10-14T00:00:00+00:00" [selected]
      - option "共享草稿 · 修订 3 · SHARED_EDITOR · 2026-10-14T00:00:00+00:00"
      - option "共享草稿 · 修订 2 · SHARED_EDITOR · 2026-10-14T00:00:00+00:00"
      - option "共享草稿 · 修订 1 · SHARED_EDITOR · 2026-10-14T00:00:00+00:00"
    - button "刷新历史版本"
    - paragraph: 选定修订 4 · 当时输入版本 1 · 2026-10-14T00:00:00+00:00 · SHARED_EDITOR。计算时点 2026-10-14T00:00:00Z。
    - button "导出选定快照 Excel"
    - button "恢复为新草稿并预览"
    - table "历史每日投入":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 日内顺序 投入数量 生产工时":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "日内顺序"
            - columnheader "投入数量"
            - columnheader "生产工时"
      - table:
        - rowgroup:
          - row "2027-01-24 L M 0 101 3.0000 小时":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell "0"
            - cell "101"
            - cell "3.0000 小时":
              - text: 3.0000 小时
              - group: 查看精确值 小时
          - row "2027-01-18 L M 0 100 3.0000 小时":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell "0"
            - cell "100"
            - cell "3.0000 小时":
              - text: 3.0000 小时
              - group: 查看精确值 小时
          - row "2026-10-17 L N 0 3 1.0000 小时":
            - cell "2026-10-17"
            - cell "L"
            - cell "N"
            - cell "0"
            - cell "3"
            - cell "1.0000 小时":
              - text: 1.0000 小时
              - group: 查看精确值 小时
    - group: 当时需求、参数、日历与确认
    - group: 当时执行事实与锁定
    - paragraph: 当时计划变动代价 0；日内顺序变动数 0。
    - table "历史稳定性":
      - table:
        - rowgroup:
          - row "实际需求周 当时变化率":
            - columnheader "实际需求周"
            - columnheader "当时变化率"
      - table:
        - rowgroup:
          - row "2026-10-12 新排计划":
            - cell "2026-10-12"
            - cell "新排计划"
          - row "2026-10-19 新排计划":
            - cell "2026-10-19"
            - cell "新排计划"
          - row "2026-10-26 新排计划":
            - cell "2026-10-26"
            - cell "新排计划"
          - row "2026-11-02 新排计划":
            - cell "2026-11-02"
            - cell "新排计划"
          - row "2026-11-09 新排计划":
            - cell "2026-11-09"
            - cell "新排计划"
          - row "2026-11-16 新排计划":
            - cell "2026-11-16"
            - cell "新排计划"
          - row "2026-11-23 新排计划":
            - cell "2026-11-23"
            - cell "新排计划"
          - row "2026-11-30 新排计划":
            - cell "2026-11-30"
            - cell "新排计划"
          - row "2026-12-07 新排计划":
            - cell "2026-12-07"
            - cell "新排计划"
          - row "2026-12-14 新排计划":
            - cell "2026-12-14"
            - cell "新排计划"
          - row "2026-12-21 新排计划":
            - cell "2026-12-21"
            - cell "新排计划"
          - row "2026-12-28 新排计划":
            - cell "2026-12-28"
            - cell "新排计划"
          - row "2027-01-04 新排计划":
            - cell "2027-01-04"
            - cell "新排计划"
          - row "2027-01-11 新排计划":
            - cell "2027-01-11"
            - cell "新排计划"
          - row "2027-01-18 新排计划":
            - cell "2027-01-18"
            - cell "新排计划"
    - region "产出需求与确认核算":
      - heading "产出、需求归属与确认" [level=2]
      - paragraph: 存在硬冲突、必要未确认或未完成计算，须处理后再采用。
      - paragraph: 当前已算产出，尚未完成 3 片；窗口外 0 片；未分配 3 片。总体按时率 计算未完成。
      - paragraph: 缺口按需求减去有效按时与迟交覆盖计算。待确认是缺口中已归属、尚未有效的部分，不与缺口重复相加。迟交补足不改写按时率。
      - table "周需求覆盖":
        - rowgroup:
          - row "机种 需求周周一 需求 有效按时 按时率 有效迟交 未补足缺口 待物料 待出货":
            - columnheader "机种"
            - columnheader "需求周周一"
            - columnheader "需求"
            - columnheader "有效按时"
            - columnheader "按时率"
            - columnheader "有效迟交"
            - columnheader "未补足缺口"
            - columnheader "待物料"
            - columnheader "待出货"
        - rowgroup
      - heading "产出来源与逐笔取整" [level=3]
      - group: N · 跨线投入 · 2026-10-17 · 3 片 · 未分配产出 3 片
      - heading "来源、需求与投入归属" [level=3]
      - paragraph: 同来源同需求周的归属投入是整组值，各产出分笔重复展示该组依据，不能将其逐行相加。比例分母不含未分配产出。
      - table "产出归属确认明细":
        - rowgroup:
          - row "来源 需求周 产出日 归属产出 该周来源产出/比例分母 归属投入/未取整份额 已确认投入/缺确认投入 物料已满足产出 待物料/待出货产出 有效按时/迟交 批次使用":
            - columnheader "来源"
            - columnheader "需求周"
            - columnheader "产出日"
            - columnheader "归属产出"
            - columnheader "该周来源产出/比例分母"
            - columnheader "归属投入/未取整份额"
            - columnheader "已确认投入/缺确认投入"
            - columnheader "物料已满足产出"
            - columnheader "待物料/待出货产出"
            - columnheader "有效按时/迟交"
            - columnheader "批次使用"
        - rowgroup
      - heading "确认批次额度" [level=3]
      - table "确认批次使用":
        - rowgroup:
          - row "机种/需求周 类型/批次 状态 日期边界 原额度 使用量 余量":
            - columnheader "机种/需求周"
            - columnheader "类型/批次"
            - columnheader "状态"
            - columnheader "日期边界"
            - columnheader "原额度"
            - columnheader "使用量"
            - columnheader "余量"
        - rowgroup
  - region "周计划编辑":
    - heading "十五周计划" [level=2]
    - text: 周次
    - combobox "计划周次":
      - option "第 1 周 · W202642 · 2026-10-12" [selected]
      - option "第 2 周 · W202643 · 2026-10-19"
      - option "第 3 周 · W202644 · 2026-10-26"
      - option "第 4 周 · W202645 · 2026-11-02"
      - option "第 5 周 · W202646 · 2026-11-09"
      - option "第 6 周 · W202647 · 2026-11-16"
      - option "第 7 周 · W202648 · 2026-11-23"
      - option "第 8 周 · W202649 · 2026-11-30"
      - option "第 9 周 · W202650 · 2026-12-07"
      - option "第 10 周 · W202651 · 2026-12-14"
      - option "第 11 周 · W202652 · 2026-12-21"
      - option "第 12 周 · W202653 · 2026-12-28"
      - option "第 13 周 · W202701 · 2027-01-04"
      - option "第 14 周 · W202702 · 2027-01-11"
      - option "第 15 周 · W202703 · 2027-01-18"
    - text: 点击日期线体查看日内顺序。可跨日保留生产段选择。
    - table "十五周日期线体计划":
      - rowgroup:
        - row "线体 2026-10-12 2026-10-13 2026-10-14 2026-10-15 2026-10-16 2026-10-17 2026-10-18":
          - columnheader "线体"
          - columnheader "2026-10-12"
          - columnheader "2026-10-13"
          - columnheader "2026-10-14"
          - columnheader "2026-10-15"
          - columnheader "2026-10-16"
          - columnheader "2026-10-17"
          - columnheader "2026-10-18"
      - rowgroup:
        - row "L 一线 2026-10-12 L 日内详情 2026-10-13 L 日内详情 2026-10-14 L 日内详情 2026-10-15 L 日内详情 2026-10-16 L 日内详情 2026-10-17 L 日内详情 2026-10-18 L 日内详情":
          - rowheader "L 一线"
          - cell "2026-10-12 L 日内详情":
            - button "2026-10-12 L 日内详情": 空白
          - cell "2026-10-13 L 日内详情":
            - button "2026-10-13 L 日内详情": 空白
          - cell "2026-10-14 L 日内详情":
            - button "2026-10-14 L 日内详情": 空白
          - cell "2026-10-15 L 日内详情":
            - button "2026-10-15 L 日内详情": 空白
          - cell "2026-10-16 L 日内详情":
            - button "2026-10-16 L 日内详情": M · 17片
          - cell "2026-10-17 L 日内详情":
            - button "2026-10-17 L 日内详情": N · 3片
          - cell "2026-10-18 L 日内详情":
            - button "2026-10-18 L 日内详情": 空白
    - heading "2026-10-16 · L 日内详情" [level=3]
    - table "日内生产顺序":
      - rowgroup:
        - row "选择 顺序 / 机种 投入量 精确工时 排序":
          - columnheader "选择"
          - columnheader "顺序 / 机种"
          - columnheader "投入量"
          - columnheader "精确工时"
          - columnheader "排序"
      - rowgroup:
        - row "选择生产段 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01 0 · M 17片 12.1920 小时 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01上移 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01下移":
          - cell "选择生产段 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01":
            - checkbox "选择生产段 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01"
          - cell "0 · M"
          - cell "17片"
          - cell "12.1920 小时":
            - text: 12.1920 小时
            - group: 查看精确值 小时
          - cell "edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01上移 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01下移":
            - button "edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01上移" [disabled]: 上移
            - button "edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01下移" [disabled]: 下移
    - paragraph: 日可用 24 小时；日末 Recipe R。完整计划切机 0 次。
    - paragraph:
      - text: 生产 12.1920 小时
      - group: 查看精确值 小时
    - paragraph:
      - text: 切机 0.0000 小时
      - group: 查看精确值 小时
    - paragraph:
      - text: 总占用 12.1920 小时
      - group: 查看精确值 小时
    - table "所选日Recipe容量":
      - rowgroup:
        - row "Recipe 汇总投入 生产工时 全日产能 精确投入上限 状态":
          - columnheader "Recipe"
          - columnheader "汇总投入"
          - columnheader "生产工时"
          - columnheader "全日产能"
          - columnheader "精确投入上限"
          - columnheader "状态"
      - rowgroup:
        - row "R 17 12.1920 小时 1000 508 已知":
          - cell "R"
          - cell "17"
          - cell "12.1920 小时":
            - text: 12.1920 小时
            - group: 查看精确值 小时
          - cell "1000"
          - cell "508"
          - cell "已知"
    - group "本次授权调整范围":
      - text: 本次授权调整范围 范围起日
      - textbox "调整范围起日": 2026-10-12
      - text: 范围终日
      - textbox "调整范围终日": 2026-10-18
      - text: 可修改线体
      - listbox "调整范围线体":
        - option "L" [selected]
      - text: 可修改机种（不选表示全部）
      - listbox "调整范围机种":
        - option "M"
        - option "N"
        - option "P"
    - group "手动动作":
      - text: 手动动作 操作
      - combobox "手动操作":
        - option "追加填量" [selected]
        - option "交换两段"
        - option "移动一段"
        - option "拆分一段"
        - option "清空所选段"
        - option "复制新增"
        - option "覆盖复制"
      - paragraph: 已选 0 段：
      - button "取消生产段选择"
      - text: 机种
      - combobox "追加机种":
        - option "请选择" [selected]
        - option "M 机种一"
        - option "N 机种二"
        - option "P 机种三"
      - text: 追加起日
      - textbox "追加起日": 2026-10-12
      - text: 追加终日
      - textbox "追加终日": 2026-10-18
      - button "读取可生产线体"
      - text: 逐线选择
      - combobox "追加线体":
        - option "请选择" [selected]
      - text: 新增总量
      - spinbutton "操作数量": "1"
      - button "加入完整动作并预览"
    - form "改量与完整顺延链":
      - group "改量顺延":
        - text: 改量顺延
        - paragraph: 在日内详情中选择一段生产安排。其他已选段须先取消选择。
        - text: 改量后总量
        - spinbutton "改量后总量": "0"
        - text: 同线顺延截止日
        - textbox "顺延截止日": 2026-10-18
        - button "预览完整改量顺延" [disabled]
        - paragraph: 总量包含已执行部分。增量优先安排当前段，后续未锁定安排只在原线体与截止日内顺延；保护数量保持不变。减量不提前后续计划。
        - paragraph: 整条顺延链为一个动作。下方完整预览列出逐日变更和待确认产出，未排下的投入单列保留。
    - heading "保留的未分配投入" [level=3]
    - paragraph: 余额不会自动换线、延日或舍弃；它与需求缺口分别保留。
    - table "未分配投入":
      - rowgroup:
        - row "机种 数量 原因 处理":
          - columnheader "机种"
          - columnheader "数量"
          - columnheader "原因"
          - columnheader "处理"
      - rowgroup
  - region "数量锁定与稳定性":
    - heading "数量锁定与稳定性" [level=2]
    - paragraph: 数量锁按生产日、线体、机种的汇总量保护，包含零数量；日内顺序仍可调整。手动编辑不会自动锁定。锁定、解锁和偏好都先进入本机动作，预览后共享保存。
    - text: 锁定生产日
    - combobox "锁定生产日":
      - option "2026-10-12" [selected]
      - option "2026-10-13"
      - option "2026-10-14"
      - option "2026-10-15"
      - option "2026-10-16"
      - option "2026-10-17"
      - option "2026-10-18"
      - option "2026-10-19"
      - option "2026-10-20"
      - option "2026-10-21"
      - option "2026-10-22"
      - option "2026-10-23"
      - option "2026-10-24"
      - option "2026-10-25"
      - option "2026-10-26"
      - option "2026-10-27"
      - option "2026-10-28"
      - option "2026-10-29"
      - option "2026-10-30"
      - option "2026-10-31"
      - option "2026-11-01"
      - option "2026-11-02"
      - option "2026-11-03"
      - option "2026-11-04"
      - option "2026-11-05"
      - option "2026-11-06"
      - option "2026-11-07"
      - option "2026-11-08"
      - option "2026-11-09"
      - option "2026-11-10"
      - option "2026-11-11"
      - option "2026-11-12"
      - option "2026-11-13"
      - option "2026-11-14"
      - option "2026-11-15"
      - option "2026-11-16"
      - option "2026-11-17"
      - option "2026-11-18"
      - option "2026-11-19"
      - option "2026-11-20"
      - option "2026-11-21"
      - option "2026-11-22"
      - option "2026-11-23"
      - option "2026-11-24"
      - option "2026-11-25"
      - option "2026-11-26"
      - option "2026-11-27"
      - option "2026-11-28"
      - option "2026-11-29"
      - option "2026-11-30"
      - option "2026-12-01"
      - option "2026-12-02"
      - option "2026-12-03"
      - option "2026-12-04"
      - option "2026-12-05"
      - option "2026-12-06"
      - option "2026-12-07"
      - option "2026-12-08"
      - option "2026-12-09"
      - option "2026-12-10"
      - option "2026-12-11"
      - option "2026-12-12"
      - option "2026-12-13"
      - option "2026-12-14"
      - option "2026-12-15"
      - option "2026-12-16"
      - option "2026-12-17"
      - option "2026-12-18"
      - option "2026-12-19"
      - option "2026-12-20"
      - option "2026-12-21"
      - option "2026-12-22"
      - option "2026-12-23"
      - option "2026-12-24"
      - option "2026-12-25"
      - option "2026-12-26"
      - option "2026-12-27"
      - option "2026-12-28"
      - option "2026-12-29"
      - option "2026-12-30"
      - option "2026-12-31"
      - option "2027-01-01"
      - option "2027-01-02"
      - option "2027-01-03"
      - option "2027-01-04"
      - option "2027-01-05"
      - option "2027-01-06"
      - option "2027-01-07"
      - option "2027-01-08"
      - option "2027-01-09"
      - option "2027-01-10"
      - option "2027-01-11"
      - option "2027-01-12"
      - option "2027-01-13"
      - option "2027-01-14"
      - option "2027-01-15"
      - option "2027-01-16"
      - option "2027-01-17"
      - option "2027-01-18"
      - option "2027-01-19"
      - option "2027-01-20"
      - option "2027-01-21"
      - option "2027-01-22"
      - option "2027-01-23"
      - option "2027-01-24"
    - text: 锁定线体
    - combobox "锁定线体":
      - option "L 一线" [selected]
    - text: 锁定机种
    - combobox "锁定机种":
      - option "M 机种一" [selected]
      - option "N 机种二"
      - option "P 机种三"
    - button "加入锁定批次"
    - list "待锁定批次"
    - button "批量锁定所选数量" [disabled]
    - table "当前数量锁":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 锁定数量 显式解锁":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "锁定数量"
            - columnheader "显式解锁"
      - table:
        - rowgroup
      - text: 没有数量锁
    - button "批量解锁全部当前锁" [disabled]
    - group "稳定性偏好":
      - text: 稳定性偏好 近期截至第几周
      - spinbutton "近期截至周": "4"
      - text: 近期容忍度 %
      - textbox "近期容忍度": "10"
      - text: 远期容忍度 %
      - textbox "远期容忍度": "30"
      - text: 近期变动权重
      - textbox "近期变动权重": "3"
      - text: 远期变动权重
      - textbox "远期变动权重": "1"
      - button "预览偏好变更"
    - paragraph: 最近采用基线 尚未建立 · 计划变动代价 0 · 日内顺序变动数 0
    - paragraph: 逐周按实际日期比较；同一确认执行量从两边各扣除一次。容忍度只作提示，超出后仍可明确采用。
    - paragraph: 未建立基线的范围不计变化率或变动代价。未知执行量不按零计算；部分覆盖的数值只代表已知范围。
    - table "逐周稳定性":
      - table:
        - rowgroup:
          - row "当前窗口周 实际周一起日 分段 可比较旧待执行量 可比较新待执行量 绝对变化片数 变化率及状态 容忍度 提示":
            - columnheader "当前窗口周"
            - columnheader "实际周一起日"
            - columnheader "分段"
            - columnheader "可比较旧待执行量"
            - columnheader "可比较新待执行量"
            - columnheader "绝对变化片数"
            - columnheader "变化率及状态"
            - columnheader "容忍度"
            - columnheader "提示"
      - table:
        - rowgroup:
          - row "1 2026-10-12 近期 无基线 未比较 0 新排计划 10% 含未建立基线的单元格":
            - cell "1"
            - cell "2026-10-12"
            - cell "近期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "10%"
            - cell "含未建立基线的单元格"
          - row "2 2026-10-19 近期 无基线 未比较 0 新排计划 10%":
            - cell "2"
            - cell "2026-10-19"
            - cell "近期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "10%"
            - cell
          - row "3 2026-10-26 近期 无基线 未比较 0 新排计划 10%":
            - cell "3"
            - cell "2026-10-26"
            - cell "近期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "10%"
            - cell
          - row "4 2026-11-02 近期 无基线 未比较 0 新排计划 10%":
            - cell "4"
            - cell "2026-11-02"
            - cell "近期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "10%"
            - cell
          - row "5 2026-11-09 远期 无基线 未比较 0 新排计划 30%":
            - cell "5"
            - cell "2026-11-09"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "6 2026-11-16 远期 无基线 未比较 0 新排计划 30%":
            - cell "6"
            - cell "2026-11-16"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "7 2026-11-23 远期 无基线 未比较 0 新排计划 30%":
            - cell "7"
            - cell "2026-11-23"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "8 2026-11-30 远期 无基线 未比较 0 新排计划 30%":
            - cell "8"
            - cell "2026-11-30"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "9 2026-12-07 远期 无基线 未比较 0 新排计划 30%":
            - cell "9"
            - cell "2026-12-07"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "10 2026-12-14 远期 无基线 未比较 0 新排计划 30%":
            - cell "10"
            - cell "2026-12-14"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "11 2026-12-21 远期 无基线 未比较 0 新排计划 30%":
            - cell "11"
            - cell "2026-12-21"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "12 2026-12-28 远期 无基线 未比较 0 新排计划 30%":
            - cell "12"
            - cell "2026-12-28"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "13 2027-01-04 远期 无基线 未比较 0 新排计划 30%":
            - cell "13"
            - cell "2027-01-04"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "14 2027-01-11 远期 无基线 未比较 0 新排计划 30%":
            - cell "14"
            - cell "2027-01-11"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell
          - row "15 2027-01-18 远期 无基线 未比较 0 新排计划 30% 含未建立基线的单元格":
            - cell "15"
            - cell "2027-01-18"
            - cell "远期"
            - cell "无基线"
            - cell "未比较"
            - cell "0"
            - cell "新排计划"
            - cell "30%"
            - cell "含未建立基线的单元格"
  - region "执行事实与每周重置":
    - heading "执行事实与每周重置" [level=2]
    - paragraph: 累计事实按生产日、线体、机种替换，未提供的记录保留。超计划及计划外实际投入单独保留。周一起始在制品只计产出，最终净余额只调整来源周投入目标。
    - group "累计执行事实":
      - text: 累计执行事实 事实生产日
      - textbox "事实生产日": 2026-10-14
      - text: 事实线体
      - combobox "事实线体":
        - option "L 一线" [selected]
      - text: 事实机种
      - combobox "事实机种":
        - option "M 机种一" [selected]
        - option "N 机种二"
        - option "P 机种三"
      - text: 累计实际投入
      - textbox "累计实际投入"
      - button "加入累计事实"
      - text: 截止时点，北京时间
      - textbox "执行截止时点": 2026-10-14T08:00
      - text: 事实纠错原因
      - textbox "事实纠错原因"
    - list "待登记累计事实"
    - group: 确认执行覆盖与空白含义
    - button "预览执行事实"
    - paragraph: 执行截止 尚未确认；未声明的空白保持未知。
    - table "当前累计执行事实":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 累计实际投入":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "累计实际投入"
      - table:
        - rowgroup
      - text: 尚未登记事实
    - table "超计划与计划外事实":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 未关联计划段的实际投入":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "未关联计划段的实际投入"
      - table:
        - rowgroup
      - text: 没有超计划或计划外实际投入
    - group: 原顺序执行分段与关联纠错
    - group: 事实纠错与登记审计
    - group "当日剩余容量确认":
      - text: 当日剩余容量确认
      - paragraph: 只使用你确认的剩余可用工时与当前 Recipe，不按已过钟点推算。事实或参数变化后须重新确认。
      - text: L 剩余可用工时
      - textbox "当日剩余可用工时"
      - text: 当前 Recipe
      - combobox "确认当前 Recipe":
        - option "R" [selected]
        - option "S"
      - text: 观察时点，北京时间
      - textbox "剩余容量观察时点": 2026-10-14T08:00
      - button "预览当日容量确认"
    - heading "本周配对快照" [level=3]
    - paragraph: 截止 2026-10-12 周一08:00，北京时间。每个参与机种的在制品与最终净余额同批必填，零也须明确填写。新快照完整替换旧快照，不叠加旧余额或未完成调整量。
    - group:
      - text: 重置批次
      - textbox "重置批次": week-2026-10-12
      - checkbox "更正本周重置"
      - text: 更正本周重置 授权起日
      - textbox "重置授权起日": 2026-10-12
      - text: 授权终日
      - textbox "重置授权终日": 2027-01-24
      - text: 授权线体
      - listbox "重置授权线体":
        - option "L" [selected]
      - text: 授权机种，空选表示全部
      - listbox "重置授权机种":
        - option "M"
        - option "N"
        - option "P"
    - table "同批在制品与最终净余额":
      - table:
        - rowgroup:
          - row "机种 周一起始在制品 最终净余额，正超前、负落后":
            - columnheader "机种"
            - columnheader "周一起始在制品"
            - columnheader "最终净余额，正超前、负落后"
      - table:
        - rowgroup:
          - row "M":
            - cell "M"
            - cell:
              - textbox "M 周一起始在制品"
            - cell:
              - textbox "M 最终净余额"
          - row "N":
            - cell "N"
            - cell:
              - textbox "N 周一起始在制品"
            - cell:
              - textbox "N 最终净余额"
          - row "P":
            - cell "P"
            - cell:
              - textbox "P 周一起始在制品"
            - cell:
              - textbox "P 最终净余额"
    - button "预览本周重置" [disabled]
  - region "本机完整动作队列":
    - heading "本机动作" [level=2]
    - paragraph: 按完整动作选取后重新预览；交换两端、拆分与复制组保持完整。取消选取会使旧预览失效。
    - checkbox "追加填量 · M / 17片 / L / 2026-10-16 / 2026-10-16 / 范围 2026-10-12 至 2026-10-18，L" [checked]
    - text: 追加填量 · M / 17片 / L / 2026-10-16 / 2026-10-16 / 范围 2026-10-12 至 2026-10-18，L
    - checkbox "追加填量 · M / 9片 / L / 2026-10-16 / 2026-10-16 / 范围 2026-10-12 至 2026-10-18，L"
    - text: 追加填量 · M / 9片 / L / 2026-10-16 / 2026-10-16 / 范围 2026-10-12 至 2026-10-18，L
    - button "撤销最后完整动作"
  - checkbox "保存为待处理草稿"
  - text: 保存为待处理草稿
  - button "预览本机修改"
  - button "共享保存"
  - button "正式采用" [disabled]
  - region "完整动作影响预览":
    - heading "完整影响预览" [level=2]
    - table "本次完整计划变更":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 变更事项 调整前 调整后":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "变更事项"
            - columnheader "调整前"
            - columnheader "调整后"
      - table:
        - rowgroup:
          - row "2026-10-16 L M 生产段 无 记录 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01；生产日 2026-10-16；线体 L；顺序 0；机种 M；数量 17；精确工时 1524/125":
            - cell "2026-10-16"
            - cell "L"
            - cell "M"
            - cell "生产段"
            - cell "无"
            - cell "记录 edit-07db91e87c1d77ed1af7875e6403d9f3705c9d01；生产日 2026-10-16；线体 L；顺序 0；机种 M；数量 17；精确工时 1524/125"
    - group: 关联检查范围 (2)
    - heading "冲突及待确认定位" [level=3]
    - table "完整业务问题":
      - table:
        - rowgroup:
          - row "生产日 线体 机种 原需求周 相关批次 原因":
            - columnheader "生产日"
            - columnheader "线体"
            - columnheader "机种"
            - columnheader "原需求周"
            - columnheader "相关批次"
            - columnheader "原因"
      - table:
        - rowgroup:
          - row "2027-01-18 L M Recipe 汇总投入100超过精确工时上限0":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "Recipe 汇总投入100超过精确工时上限0"
          - row "2027-01-18 L M 缺少全日产能，按零计算，待补充":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少全日产能，按零计算，待补充"
          - row "2027-01-18 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少关键良率或 Cycle Time，相关产出尚未计算完成"
          - row "2027-01-18 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少关键良率或 Cycle Time，相关产出尚未计算完成"
          - row "2027-01-24 L M Recipe 汇总投入101超过精确工时上限0":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "Recipe 汇总投入101超过精确工时上限0"
          - row "2027-01-24 L M 缺少全日产能，按零计算，待补充":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少全日产能，按零计算，待补充"
          - row "2027-01-24 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少关键良率或 Cycle Time，相关产出尚未计算完成"
          - row "2027-01-24 L M 缺少关键良率或 Cycle Time，相关产出尚未计算完成":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "缺少关键良率或 Cycle Time，相关产出尚未计算完成"
          - row "2027-01-18 L M 投入来源缺少关键良率或 Cycle Time":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "投入来源缺少关键良率或 Cycle Time"
          - row "2027-01-18 L M 投入来源缺少关键良率或 Cycle Time":
            - cell "2027-01-18"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "投入来源缺少关键良率或 Cycle Time"
          - row "2027-01-24 L M 投入来源缺少关键良率或 Cycle Time":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "投入来源缺少关键良率或 Cycle Time"
          - row "2027-01-24 L M 投入来源缺少关键良率或 Cycle Time":
            - cell "2027-01-24"
            - cell "L"
            - cell "M"
            - cell
            - cell
            - cell "投入来源缺少关键良率或 Cycle Time"
  - region "产出需求与确认核算":
    - heading "产出、需求归属与确认" [level=2]
    - paragraph: 存在硬冲突、必要未确认或未完成计算，须处理后再采用。
    - paragraph: 当前已算产出，尚未完成 20 片；窗口外 0 片；未分配 20 片。总体按时率 计算未完成。
    - paragraph: 缺口按需求减去有效按时与迟交覆盖计算。待确认是缺口中已归属、尚未有效的部分，不与缺口重复相加。迟交补足不改写按时率。
    - table "周需求覆盖":
      - rowgroup:
        - row "机种 需求周周一 需求 有效按时 按时率 有效迟交 未补足缺口 待物料 待出货":
          - columnheader "机种"
          - columnheader "需求周周一"
          - columnheader "需求"
          - columnheader "有效按时"
          - columnheader "按时率"
          - columnheader "有效迟交"
          - columnheader "未补足缺口"
          - columnheader "待物料"
          - columnheader "待出货"
      - rowgroup
    - heading "产出来源与逐笔取整" [level=3]
    - group: M · 跨线投入 · 2026-10-16 · 17 片 · 未分配产出 17 片
    - group: N · 跨线投入 · 2026-10-17 · 3 片 · 未分配产出 3 片
    - heading "来源、需求与投入归属" [level=3]
    - paragraph: 同来源同需求周的归属投入是整组值，各产出分笔重复展示该组依据，不能将其逐行相加。比例分母不含未分配产出。
    - table "产出归属确认明细":
      - rowgroup:
        - row "来源 需求周 产出日 归属产出 该周来源产出/比例分母 归属投入/未取整份额 已确认投入/缺确认投入 物料已满足产出 待物料/待出货产出 有效按时/迟交 批次使用":
          - columnheader "来源"
          - columnheader "需求周"
          - columnheader "产出日"
          - columnheader "归属产出"
          - columnheader "该周来源产出/比例分母"
          - columnheader "归属投入/未取整份额"
          - columnheader "已确认投入/缺确认投入"
          - columnheader "物料已满足产出"
          - columnheader "待物料/待出货产出"
          - columnheader "有效按时/迟交"
          - columnheader "批次使用"
      - rowgroup
    - heading "确认批次额度" [level=3]
    - table "确认批次使用":
      - rowgroup:
        - row "机种/需求周 类型/批次 状态 日期边界 原额度 使用量 余量":
          - columnheader "机种/需求周"
          - columnheader "类型/批次"
          - columnheader "状态"
          - columnheader "日期边界"
          - columnheader "原额度"
          - columnheader "使用量"
          - columnheader "余量"
      - rowgroup
```

# Test source

```ts
  1   | import {test,expect,Page} from '@playwright/test'
  2   | const origin=`https://localhost:${process.env.AUTO_PLAN_BROWSER_PORT ?? '8774'}`
  3   | const headers={Origin:origin,'X-Auto-Plan-Request':'1'}
  4   | async function login(page:Page,user='SHARED_EDITOR'){
  5   |   await page.goto('/planning/login')
  6   |   await page.getByRole('textbox',{name:'公司账号'}).fill(user)
  7   |   await page.getByLabel('公司密码',{exact:true}).fill('company-secret')
  8   |   await page.getByRole('button',{name:'登录',exact:true}).click()
  9   |   await page.getByRole('link',{name:'共享计划',exact:true}).click()
  10  |   await expect(page.getByLabel('操作数量',{exact:true})).toBeEnabled()
  11  | }
  12  | async function append(page:Page,quantity='17'){
  13  |   await page.getByLabel('追加机种',{exact:true}).selectOption('M')
  14  |   await page.getByLabel('追加起日',{exact:true}).fill('2026-10-16')
  15  |   await page.getByLabel('追加终日',{exact:true}).fill('2026-10-16')
  16  |   await page.getByRole('button',{name:'读取可生产线体',exact:true}).click()
  17  |   await expect(page.getByLabel('追加线体',{exact:true}).locator('option[value="L"]')).toBeAttached()
  18  |   await page.getByLabel('追加线体',{exact:true}).selectOption('L')
  19  |   await page.getByLabel('操作数量',{exact:true}).fill(quantity)
  20  |   await page.getByRole('button',{name:'加入完整动作并预览',exact:true}).click()
  21  |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  22  | }
  23  | test.beforeEach(()=>test.skip(process.env.AUTO_PLAN_BROWSER_TRANSACTIONS_FIXTURE!=='1','Requires frozen shared-plan fixture'))
  24  | test('unsent new segments recover by choice with original tokens and whole unchecked actions',async({page})=>{
  25  |   await login(page)
  26  |   const before=await(await page.request.get('/planning/api/plans/current')).json()
  27  |   await append(page)
  28  |   await append(page,'9')
  29  |   await page.getByRole('region',{name:'本机完整动作队列'}).getByRole('checkbox').last().uncheck()
  30  |   await expect(page.getByText('已暂存本机，尚未共享',{exact:true})).toBeVisible()
  31  |   const independent=await page.request.post('/planning/api/plans/save',{headers,data:{
  32  |     base_revision:before.revision,input_version:before.input_version,latest_adoption:before.latest_adoption,
  33  |     operation_id:crypto.randomUUID(),pending:true,operations:[{kind:'patch_plan',segments:[{id:'independent-recovery-row',date:'2026-10-17',line_code:'L',model_code:'N',quantity:3,hours:'1',order:0}]}],
  34  |   }})
  35  |   expect(independent.ok()).toBeTruthy()
  36  |   await page.reload()
  37  |   await expect(page.getByRole('button',{name:'恢复本机临时稿',exact:true})).toBeVisible()
  38  |   await expect(page.getByLabel('操作数量',{exact:true})).toBeDisabled()
  39  |   await page.getByRole('button',{name:'恢复本机临时稿',exact:true}).click()
  40  |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('17片')
  41  |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('9片')
  42  |   await expect(page.getByRole('region',{name:'本机完整动作队列'}).getByRole('checkbox').last()).not.toBeChecked()
  43  |   await expect(page.getByText(`原共享修订 ${before.revision} / 当前 ${before.revision+1}`,{exact:true})).toBeVisible()
  44  |   await expect(page.getByRole('table',{name:'本机恢复期间的共享变更'})).toContainText('2026-10-17')
  45  |   await expect(page.getByRole('button',{name:'共享保存',exact:true})).toBeDisabled()
  46  |   await page.getByRole('button',{name:'预览本机修改',exact:true}).click()
  47  |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  48  |   await page.getByRole('button',{name:'2026-10-16 L 日内详情',exact:true}).click()
  49  |   await expect(page.getByRole('table',{name:'日内生产顺序'})).toContainText('17片')
  50  |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
> 51  |   await expect(page.getByText(/已共享保存修订/)).toBeVisible()
      |                                           ^ Error: expect(locator).toBeVisible() failed
  52  |   const after=await(await page.request.get('/planning/api/plans/current')).json()
  53  |   expect(after.plan.segments.find((row:{id:string})=>row.id==='independent-recovery-row').quantity).toBe(3)
  54  |   expect(after.plan.segments.filter((row:{date:string})=>row.date==='2026-10-16').map((row:{quantity:number})=>row.quantity)).toContain(17)
  55  |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('9片')
  56  | })
  57  | test('native Web Lock takeover revokes the former editor and offline stops both tabs',async({page,context})=>{
  58  |   await login(page);await append(page,'31')
  59  |   const other=await context.newPage()
  60  |   await other.goto('/planning/plans/shared')
  61  |   await expect(other.getByLabel('操作数量',{exact:true})).toBeDisabled()
  62  |   expect(await other.evaluate(async()=>((await navigator.locks.query()).held ?? []).filter(lock=>lock.name?.includes(':draft:main')).length)).toBe(1)
  63  |   await other.getByRole('button',{name:'接管本机临时稿',exact:true}).click()
  64  |   await expect(page.getByLabel('操作数量',{exact:true})).toBeDisabled()
  65  |   await expect(other.getByRole('button',{name:'恢复本机临时稿',exact:true})).toBeEnabled()
  66  |   await other.getByRole('button',{name:'恢复本机临时稿',exact:true}).click()
  67  |   await expect(other.getByLabel('操作数量',{exact:true})).toBeEnabled()
  68  |   await expect(other.getByRole('region',{name:'本机完整动作队列'})).toContainText('31片')
  69  |   expect(await other.evaluate(async()=>((await navigator.locks.query()).held ?? []).filter(lock=>lock.name?.includes(':draft:main')).length)).toBe(1)
  70  |   await context.setOffline(true)
  71  |   await expect(other.getByLabel('操作数量',{exact:true})).toBeDisabled()
  72  |   await expect(page.getByLabel('操作数量',{exact:true})).toBeDisabled()
  73  |   await context.setOffline(false)
  74  |   await expect(other.getByLabel('操作数量',{exact:true})).toBeEnabled()
  75  |   await other.getByRole('button',{name:'新建本机临时稿',exact:true}).click()
  76  |   await expect(other.getByLabel('操作数量',{exact:true})).toBeEnabled()
  77  |   await expect(other.getByRole('region',{name:'本机完整动作队列'}).getByRole('checkbox')).toHaveCount(0)
  78  |   await other.getByLabel('本机草稿编号',{exact:true}).selectOption('main')
  79  |   await other.getByRole('button',{name:'恢复本机临时稿',exact:true}).click()
  80  |   await expect(other.getByRole('region',{name:'本机完整动作队列'})).toContainText('31片')
  81  | })
  82  | test('recovered stale intent conflicts before explicit recheck, unknown commit verifies and void retains new segments',async({page})=>{
  83  |   await login(page);await append(page,'13')
  84  |   const initial=await(await page.request.get('/planning/api/plans/current')).json()
  85  |   const existing=initial.plan.segments.find((row:{date:string;model_code:string})=>row.date==='2026-10-16' && row.model_code==='M')
  86  |   const other=await page.request.post('/planning/api/plans/save',{headers,data:{
  87  |     base_revision:initial.revision,input_version:initial.input_version,latest_adoption:initial.latest_adoption,
  88  |     operation_id:crypto.randomUUID(),pending:true,operations:[{kind:'patch_plan',segments:[existing ? {...existing,quantity:existing.quantity+1} : {id:'other-local-cell',date:'2026-10-16',line_code:'L',model_code:'M',quantity:1,hours:'1',order:0}]}],
  89  |   }})
  90  |   expect(other.ok()).toBeTruthy()
  91  |   await page.reload();await page.getByRole('button',{name:'恢复本机临时稿',exact:true}).click()
  92  |   await expect(page.getByText(`原共享修订 ${initial.revision} / 当前 ${initial.revision+1}`,{exact:true})).toBeVisible()
  93  |   await expect(page.getByRole('table',{name:'本机恢复期间的共享变更'})).toContainText('2026-10-16')
  94  |   await page.getByRole('button',{name:'预览本机修改',exact:true}).click()
  95  |   await expect(page.getByText('其他用户已修改关联范围，请核对差异',{exact:true})).toBeVisible()
  96  |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('13片')
  97  |   await page.getByRole('button',{name:'按最新资料重新预览',exact:true}).click()
  98  |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  99  |   await page.route('**/api/plans/save',async route=>{await route.fetch();await route.abort('failed')},{times:1})
  100 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  101 |   await expect(page.getByRole('button',{name:'核实前次操作',exact:true})).toBeVisible()
  102 |   await page.reload()
  103 |   await expect(page.getByLabel('操作数量',{exact:true})).toBeDisabled()
  104 |   await page.getByRole('button',{name:'核实前次操作',exact:true}).click()
  105 |   await expect(page.getByText(/已核实前次操作成功/)).toBeVisible()
  106 |   const committed=await(await page.request.get('/planning/api/plans/current')).json()
  107 |   expect(committed.revision).toBe(initial.revision+2)
  108 |   await append(page,'7')
  109 |   let voidId=''
  110 |   await page.route('**/api/plans/save',route=>{voidId=route.request().postDataJSON().operation_id;return route.abort('failed')},{times:1})
  111 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  112 |   await expect(page.getByRole('button',{name:'核实前次操作',exact:true})).toBeVisible()
  113 |   await page.reload();await page.getByRole('button',{name:'核实前次操作',exact:true}).click()
  114 |   await expect(page.getByText(/已核实前次操作作废/)).toBeVisible()
  115 |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('7片')
  116 |   expect((await(await page.request.get('/planning/api/plans/current')).json()).revision).toBe(committed.revision)
  117 |   await expect(page.getByRole('button',{name:'共享保存',exact:true})).toBeDisabled()
  118 |   await page.getByRole('button',{name:'预览本机修改',exact:true}).click()
  119 |   const response=page.waitForResponse(response=>response.url().endsWith('/api/plans/save'))
  120 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  121 |   const sent=await response
  122 |   expect(sent.request().postDataJSON().operation_id).not.toBe(voidId)
  123 |   await expect(page.getByText(/已共享保存修订/)).toBeVisible()
  124 |   expect((await(await page.request.get('/planning/api/plans/current')).json()).revision).toBe(committed.revision+1)
  125 | })
  126 | test('real browser quota failure preserves actions and permits an explicit shared save',async({page},testInfo)=>{
  127 |   await login(page);await append(page,'19')
  128 |   const before=await(await page.request.get('/planning/api/plans/current')).json()
  129 |   const quota=await page.evaluate(()=>{
  130 |     let low=0,high=6*1024*1024,lastError=''
  131 |     while(low<=high){
  132 |       const size=Math.floor((low+high)/2)
  133 |       try{localStorage.setItem('quota-fixture','x'.repeat(size));low=size+1}
  134 |       catch(e){lastError=(e as DOMException).name;high=size-1}
  135 |     }
  136 |     return {nativeError:lastError,fillerCharacters:high}
  137 |   })
  138 |   expect(quota.nativeError).toBe('QuotaExceededError')
  139 |   await testInfo.attach('native-quota.json',{body:JSON.stringify(quota),contentType:'application/json'})
  140 |   await append(page,'23')
  141 |   await expect(page.getByText('未暂存，页面修改仍保留',{exact:true})).toBeVisible()
  142 |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('19片')
  143 |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('23片')
  144 |   await expect(page.getByText(/刷新或关闭后无法保证恢复/).first()).toBeVisible()
  145 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  146 |   await expect(page.getByText(/已共享保存修订/)).toBeVisible()
  147 |   const after=await(await page.request.get('/planning/api/plans/current')).json()
  148 |   expect(after.revision).toBe(before.revision+1)
  149 |   expect(after.plan.segments.filter((row:{date:string})=>row.date==='2026-10-16').reduce((total:number,row:{quantity:number})=>total+row.quantity,0))
  150 |     .toBe(before.plan.segments.filter((row:{date:string})=>row.date==='2026-10-16').reduce((total:number,row:{quantity:number})=>total+row.quantity,0)+42)
  151 |   await page.evaluate(()=>localStorage.removeItem('quota-fixture'))
```