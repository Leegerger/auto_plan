# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: stability.spec.ts >> batch aggregate/zero locks, explicit unlock and preferences share the one action queue
- Location: tests/stability.spec.ts:2:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('list', { name: '待锁定批次' })
Expected substring: "200片"
Received string:    "2026-10-15 / L / M / 241片  移除2026-10-16 / L / M / 0片 锁零 移除"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('list', { name: '待锁定批次' }) with timeout 5000ms
  - waiting for getByRole('list', { name: '待锁定批次' })
    14 × locator resolved to <ul data-v-ce277d55="" aria-label="待锁定批次">…</ul>
       - unexpected value "2026-10-15 / L / M / 241片  移除2026-10-16 / L / M / 0片 锁零 移除"

```

```yaml
- list "待锁定批次":
  - listitem:
    - text: 2026-10-15 / L / M / 241片
    - button "移除"
  - listitem:
    - text: 2026-10-16 / L / M / 0片 锁零
    - button "移除"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | test('batch aggregate/zero locks, explicit unlock and preferences share the one action queue',async({page})=>{
  3  |   test.skip(process.env.AUTO_PLAN_BROWSER_TRANSACTIONS_FIXTURE!=='1','Requires explicit frozen shared-plan fixture')
  4  |   await page.goto('/planning/login')
  5  |   await page.getByRole('textbox',{name:'公司账号'}).fill('SHARED_EDITOR')
  6  |   await page.getByLabel('公司密码',{exact:true}).fill('company-secret')
  7  |   await page.getByRole('button',{name:'登录',exact:true}).click()
  8  |   await page.getByRole('link',{name:'共享计划',exact:true}).click()
  9  |   const panel=page.getByRole('region',{name:'数量锁定与稳定性'})
  10 |   await expect(panel).toBeVisible()
  11 |   await page.getByLabel('锁定生产日',{exact:true}).selectOption('2026-10-15')
  12 |   await expect(page.getByLabel('锁定线体',{exact:true}).locator('option[value="L"]')).toBeAttached()
  13 |   await page.getByLabel('锁定线体',{exact:true}).selectOption('L')
  14 |   await page.getByLabel('锁定机种',{exact:true}).selectOption('M')
  15 |   await page.getByRole('button',{name:'加入锁定批次',exact:true}).click()
  16 |   await page.getByLabel('锁定生产日',{exact:true}).selectOption('2026-10-16')
  17 |   await page.getByRole('button',{name:'加入锁定批次',exact:true}).click()
> 18 |   await expect(page.getByRole('list',{name:'待锁定批次'})).toContainText('200片')
     |                                                       ^ Error: expect(locator).toContainText(expected) failed
  19 |   await expect(page.getByRole('list',{name:'待锁定批次'})).toContainText('0片 锁零')
  20 |   await page.getByRole('button',{name:'批量锁定所选数量',exact:true}).click()
  21 |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  22 |   await expect(page.getByRole('table',{name:'当前数量锁'})).toContainText('锁零')
  23 |   const before=await(await page.request.get('/planning/api/plans/current')).json()
  24 |   expect(before.context.locks).toEqual([])
  25 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  26 |   await expect(page.getByText(/已共享保存修订/)).toBeVisible()
  27 |   const after=await(await page.request.get('/planning/api/plans/current')).json()
  28 |   expect(after.input_version).toBe(before.input_version+1)
  29 |   expect(after.context.locks).toHaveLength(2)
  30 |   await page.getByRole('button',{name:'批量解锁全部当前锁',exact:true}).click()
  31 |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  32 |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('显式解锁')
  33 |   await page.getByLabel('近期截至周',{exact:true}).fill('15')
  34 |   await page.getByLabel('近期容忍度',{exact:true}).fill('12.50')
  35 |   await page.getByLabel('近期变动权重',{exact:true}).fill('4')
  36 |   await page.getByRole('button',{name:'预览偏好变更',exact:true}).click()
  37 |   await expect(page.getByText('预览完成，尚未共享',{exact:true})).toBeVisible()
  38 |   await expect(page.getByRole('region',{name:'本机完整动作队列'})).toContainText('稳定性偏好')
  39 |   await page.getByRole('button',{name:'共享保存',exact:true}).click()
  40 |   await expect(page.getByText(/已共享保存修订/)).toBeVisible()
  41 |   const final=await(await page.request.get('/planning/api/plans/current')).json()
  42 |   expect(final.context.locks).toEqual([])
  43 |   expect(final.context.preferences.near_weeks).toBe(15)
  44 |   expect(final.context.preferences.near_tolerance_percent).toBe('25/2')
  45 |   expect(final.input_version).toBe(after.input_version+1)
  46 |   await expect(page.getByLabel('近期容忍度',{exact:true})).toHaveValue('12.5')
  47 |   await expect(page.getByRole('table',{name:'逐周稳定性'})).toContainText('12.5%')
  48 |   await expect(page.getByRole('table',{name:'逐周稳定性'})).toContainText('新排计划')
  49 |   await page.screenshot({path:'/tmp/auto-plan-spec-23/stability-ui.png',fullPage:true})
  50 | })
  51 | 
```