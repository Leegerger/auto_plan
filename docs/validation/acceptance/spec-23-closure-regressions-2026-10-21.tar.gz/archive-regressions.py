import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/root/codes/vibe_coding/auto_plan_2')
output = Path('/tmp/spec-23-close')
target = root / 'docs/validation/acceptance'
tested_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
results = json.loads((output / 'regression-results.json').read_text())
required = ['job-functional-regressions', 'adapter-pin-regressions', 'frontend-build', 'node-contracts', 'browser-default', 'browser-shared', 'browser-initialization', 'browser-output', 'browser-reset']
latest = {row['name']: row for row in results}
assert all(latest[name]['exit_code'] == 0 for name in required)

cases = {}
suite_results = []
for name in ['python', 'business-regressions', 'job-functional-regressions', 'adapter-pin-regressions']:
    tree = ET.parse(output / (name + '.xml')).getroot()
    totals = {'passed': 0, 'skipped': 0, 'failed': 0, 'errors': 0}
    for case in tree.iter('testcase'):
        state = 'failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
        totals[state] += 1
        key = case.attrib.get('classname', '') + '::' + case.attrib['name']
        cases[key] = {'state': state, 'run': name}
    suite_results.append({'name': name, **totals})
assert not any(case['state'] in ('failed', 'errors') for case in cases.values())
current = {state: sum(case['state'] == state for case in cases.values()) for state in ['passed', 'skipped', 'failed', 'errors']}

historical_sources = {
    'business-regressions': '99e92cd7455a61693a2a1c07149c282e87b403e9',
    'job-functional-regressions': '76f779a29fe7e236351b4d03a1a08e8231295e48',
    'adapter-pin-regressions': '76f779a29fe7e236351b4d03a1a08e8231295e48',
    'frontend-build': '76f779a29fe7e236351b4d03a1a08e8231295e48',
    'browser-default-initial': '76f779a29fe7e236351b4d03a1a08e8231295e48',
}
for row in results:
    row['log'] = Path(row['log']).name
    if row['name'] in historical_sources:
        row['source_commit'] = historical_sources[row['name']]
        row['source_commit_provenance'] = 'Reconstructed from root execution history; not captured in the original command record.'
    elif 'source_commit' not in row:
        row['source_commit'] = None
        row['source_commit_provenance'] = 'Not captured. No source SHA is inferred for this initial command.'
    else:
        row['source_commit_provenance'] = 'Captured by the runner when the command group started.'

summaries = {}
for name in required:
    log = (output / (name + '.log')).read_text()
    # Preserve exact summary lines alongside the full original logs.
    summaries[name] = [line for line in log.splitlines() if re.search(r'(\d+ (?:passed|failed|skipped)|(?:#|ℹ) (?:tests|pass|fail|skipped|cancelled)|built in)', line)][-12:]
node_log = (output / 'node-contracts.log').read_text()
node_counts = {name: int(re.search(r'(?:#|ℹ) ' + name + r' (\d+)', node_log).group(1)) for name in ['tests', 'pass', 'fail', 'skipped', 'cancelled']}
assert node_counts == {'tests': 135, 'pass': 130, 'fail': 0, 'skipped': 5, 'cancelled': 0}

support_names = ['regression-results.json', 'python.xml', 'business-regressions.xml', 'job-functional-regressions.xml', 'adapter-pin-regressions.xml', 'standards-review.json', 'spec-review.json', 'fresh-compute-budget-red.log', 'fresh-compute-terminal-red.log', 'fresh-compute-budget-green.log', 'job-functional-budgets-green.log', 'run-regressions.py', 'archive-regressions.py']
support_names += [row['name'] + '.log' for row in results]
members = {name: (output / name).read_bytes() for name in sorted(set(support_names))}
for name in ['node-contract-spec-review.json', 'preview-spec-review.json', 'browser-default-initial-error-context.md', 'run-shared-browser-files.py', 'worktree-cleanup.json', 'spec-after-edit.json', 'children-before-close.json', 'follow-up-state.json']:
    members[name] = (output / name).read_bytes()
for dirname in ['preview-red', 'shared-browser-files', 'browser-shared-initial-test-results']:
    for path in sorted((output / dirname).rglob('*')):
        if path.is_file():
            members[str(path.relative_to(output))] = path.read_bytes()
for path in sorted(Path('/tmp/spec-23-node-guardian-diagnostic').rglob('*')):
    if path.is_file():
        members['node-guardian-diagnostic/' + str(path.relative_to('/tmp/spec-23-node-guardian-diagnostic'))] = path.read_bytes()
shared_files = json.loads((output / 'shared-browser-files/results.json').read_text())
assert len(shared_files) == 9 and all(row['exit_code'] == 0 for row in shared_files)
shared_stats = {row['file']: json.loads((output / 'shared-browser-files' / row['json_report']).read_text())['stats'] for row in shared_files}
manifest = {'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in members.items()]}
members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive_name = 'spec-23-closure-regressions-2026-10-21.tar.gz'
archive = target / archive_name
with archive.open('wb') as file:
    with gzip.GzipFile(filename='', mode='wb', fileobj=file, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for member in tar.getmembers():
        assert tar.extractfile(member).read() == members[member.name]

report = {
    'schema_version': 1,
    'issue': 'https://github.com/Leegerger/auto_plan/issues/23',
    'scope': 'Engineering implementation and representative A2 validation. Final business and production-site acceptance remain open in #40 and #22.',
    'integration_branch': 'integration/spec-23',
    'regression_source_commit': tested_commit,
    'regression_source_commit_role': 'Source of the final browser regression group; other groups have separate per-run provenance.',
    'source_provenance': 'Per-run metadata distinguishes source commits captured by the runner, source commits reconstructed from execution history, and unavailable initial provenance. No source SHA is inferred for the initial full Python or initial Node commands. Earlier business coverage is combined with targeted reruns for subsequent test-only changes. The closure commit adds validation artifacts only.',
    'representative_browser_source_commit': '99e92cd7455a61693a2a1c07149c282e87b403e9',
    'review': {
        'baseline': 'd0d6a5a369fc0599bd657c41b7509e9d30fe0d4c',
        'standards': {'remaining_findings': 0, 'evidence_member': 'standards-review.json'},
        'spec': {'remaining_findings': 0, 'evidence_member': 'spec-review.json'},
        'final_node_delta': {'remaining_findings': 0, 'spec_evidence_member': 'node-contract-spec-review.json', 'standards_evidence_member': 'standards-review.json'},
        'final_preview_fixture_delta': {'remaining_findings': 0, 'spec_evidence_member': 'preview-spec-review.json', 'standards_evidence_member': 'standards-review.json'},
    },
    'regressions': {
        'latest_required_commands_all_exit_zero': True,
        'latest_python_case_outcomes': current,
        'python_case_count': len(cases),
        'aggregation': 'Latest result per classname::name across the four retained JUnit reports; this is combined coverage, not a single clean full-suite command.',
        'python_suites': suite_results,
        'runs': results,
        'exact_summary_lines': summaries,
        'node_case_outcomes': node_counts,
        'isolated_shared_browser_file_stats': shared_stats,
        'shared_fixture_isolation': 'Each spec file starts and stops its own fresh in-memory browser server. The earlier multi-file state-contamination failure remains archived; no production reset endpoint was added.',
        'oracle_enabled': False,
        'preserved_prior_results': [
            'The initial full Python run wrote all 535 passing/skipped case outcomes before the outer 900-second process guard expired. Its actual runner exit remains 124.',
            'The subsequent 442-case business run had one fresh-compute functional-budget failure. The changed job module and browser-freeze API tests were rerun after the explicit ten-second functional fixture correction; all original business, stop and shutdown assertions remain.',
            'The initial Node run had two missing-pydantic failures from using system Python and one overly specific guardian rejection assertion. The configured rerun uses the project Python and preserves the same action gate while accepting both valid rejection paths. The initial log and actual exit1 remain archived.',
            'The initial default browser run also imported Node test files and exposed a fixed-date fixture using the real clock. Playwright now collects its existing 32 TypeScript cases only, and the default test server uses the same frozen clock as its explicit fixtures. The same precision test went red then green without changing its business assertions.',
            'The initial combined shared browser invocation reused mutable in-memory state across spec files and failed eight cases. The final run executes every shared spec file in a separate server lifecycle; original logs and error contexts remain archived.',
        ],
    },
    'representative_browser': {
        'status': 'PASS',
        'index': 'acceptance/closure-five-browser-passed-2026-10-21.json',
        'shared_save_seconds': 52.8,
        'shared_save_gate_seconds': 60,
        'candidate_display_seconds': 172.16910009765624,
        'candidate_display_gate_seconds': 180,
        'workflow_guard_seconds': 360,
        'outer_test_seconds': 286.381495514,
        'passed_editor_records': 33,
        'job_terminal_state': 'stopped',
        'target': 'Disposable in-memory adapter and synthetic authentication on a shared Linux host.',
        'previous_failed_run_index': 'acceptance/closure-five-browser-failed-2026-10-21.json',
        'historical_report_limitation': 'The historical 1f36559a report was not recovered; the new runs have independent identities and do not replace it.',
    },
    'regression_archive': {
        'path': 'acceptance/' + archive_name,
        'bytes': archive.stat().st_size,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'members': len(members),
        'manifest_sha256': hashlib.sha256(members['manifest.json']).hexdigest(),
        'format': 'USTAR sorted paths; uid/gid/mtime zero; mode0644; gzip filename empty and mtime zero',
    },
    'deferred': {
        'acceptance_follow_up': 'https://github.com/Leegerger/auto_plan/issues/40',
        'real_excel_sample': 'https://github.com/Leegerger/auto_plan/issues/22',
        'decision_map_remains_open': 'https://github.com/Leegerger/auto_plan/issues/1',
        'a2_scope_decision': 'https://github.com/Leegerger/auto_plan/issues/38#issuecomment-6219737738',
        'not_run': ['Full local/new-week browser E2E and extended repeated matrices', 'Real company authentication, 20 real accounts and five human business participants', 'User-confirmed references, real sample checks, production hardware/proxy and final business signoff'],
    },
}
(root / 'docs/validation/spec-23-closure.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'latest_python_case_outcomes': current, 'case_count': len(cases), 'archive': report['regression_archive'], 'summaries': summaries}, ensure_ascii=False, indent=2))
