import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
import {gunzipSync} from 'node:zlib'
import {assertFullSharedBrowserReport} from '/tmp/spec-23-closure-evidence/frontend/tests/acceptance/private-shared-workload.mjs'
const base='/tmp/auto-plan-private-draft-editors-kddNaa'
const sha=b=>createHash('sha256').update(b).digest('hex')
const reportBytes=readFileSync(resolve(base,'run/report.json')),report=JSON.parse(reportBytes)
assert.equal(sha(reportBytes),'222894187abd66052920c7a90063fa49cbb83a7ba083c306be4220644748df3c')
const manifest=JSON.parse(readFileSync(resolve(base,'fixtures/manifest.json')))
const scenario=manifest.scenarios[0]
const actionBytes=gunzipSync(readFileSync(resolve(base,'fixtures',scenario.action.path)))
assert.equal(sha(actionBytes),scenario.action.sha256)
const action=JSON.parse(actionBytes)
const declaration=JSON.parse(readFileSync(resolve(base,'fixtures/editing-workload-shared.json')))
const witnesses=readFileSync(resolve(base,'job-observations.ndjson'),'utf8').trim().split('\n').map(JSON.parse)
const checked=new Set()
const captured=ref=>{const bytes=readFileSync(resolve(base,'run',ref.path));assert.equal(sha(bytes),ref.sha256);checked.add(ref.path);return JSON.parse(bytes)}
assertFullSharedBrowserReport({report,declaration,captured,witnesses,action})
assert.equal(report.local_editing_contract.status,'pass');assert.equal(report.private_shared_save.status,'pass')
assert.equal(report.acceptance,'not_run');assert.deepEqual(report.repeats,[])
assert.ok(report.private_shared_save.clock.seconds<=60);assert.ok(report.private_primary_job.clock.seconds<=180)
const c=captured(report.private_primary_job.candidate_artifact).candidate
const summary={schema_version:1,kind:'offline_full_shared_browser_checker',status:'PASS',report_sha256:sha(reportBytes),checker_sha256:sha(readFileSync('/tmp/spec-23-closure-evidence/frontend/tests/acceptance/private-shared-workload.mjs')),checked_public_files:checked.size,editor_actions:report.editor_actions.length,all_editor_actions_pass:report.editor_actions.every(r=>r.status==='pass'),shared_save_seconds:report.private_shared_save.clock.seconds,shared_save_gate_seconds:60,primary_job_seconds:report.private_primary_job.clock.seconds,primary_job_gate_seconds:180,candidate_objective:c.objective,candidate_weekly_rows:c.evaluation.weekly_results.length,candidate_eligibility:c.eligibility,candidate_status_flags:Object.fromEntries(['capacity_valid','computation_complete','executable'].map(k=>[k,c.evaluation[k]])),native_progress:witnesses.filter(r=>r.kind==='progress'&&['cp_sat','highs'].includes(r.route)&&r.status==='restricted_model').map(r=>({stage:r.stage,route:r.route,status:r.status})),scope:'Offline retained-artifact verification only. Checks exact R1/R2/R3 sources and operations, original UUID recovery, all background complete edits/undos, source pins and native process lifetime through confirmed paint, complete candidate and all33 objective coordinates against the reference, 600 exact weekly rows, restored history and terminal job cleanup. No server, test workload or database was started.'}
writeFileSync('/tmp/spec-23-close/successful-probe-offline-audit.json',JSON.stringify(summary,null,2)+'\n');process.stdout.write(JSON.stringify(summary,null,2)+'\n')
